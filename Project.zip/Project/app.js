const fs = require('fs');
const mongoose = require('mongoose');
const Grid = require('gridfs');

mongoose.connect('mongodb+srv://admin:1234@cluster0.tdpjfyo.mongodb.net/?retryWrites=true&w=majority')
    .then(() => console.log('connection successfully'))
    .catch((err) => console.error(err))

const database = mongoose.connection;

const patientFullName = "Jan wavau";

    database.once('open', () => {
      console.log('Connected to MongoDB');
      const bucket = new mongoose.mongo.GridFSBucket(database.db);
    
      const fileStream = fs.createReadStream('/Users/jjaanps/Desktop/Project/file_example_MP3_700KB.mp3');
      const uploadStream = bucket.openUploadStream('audiofile.mp3', {metadata: {patientFullName}});
    
      fileStream.pipe(uploadStream);
    
      uploadStream.on('finish', () => {
        console.log('File uploaded successfully');
        mongoose.connection.close();
      });
    });
    
    database.on('error', (err) => {
      console.error('Error:', err);
    }); 